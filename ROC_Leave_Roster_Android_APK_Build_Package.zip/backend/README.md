# Shared backend integration (next phase)

The Android, iOS, Windows and PWA clients should use the same Supabase project.

Required production services:
- Supabase Auth for individual accounts
- Postgres tables for profiles, teams, leave types, leave requests, roster schedules, activation tokens and audit events
- Row Level Security policies on every table
- Server-side Edge Function to redeem one-time activation tokens
- Realtime subscriptions for approved leave and roster changes
- Server-side validation for manager approvals and manager-entered leave

Do not put service-role keys in the client app. Only the publishable/anon key belongs in client config, protected by RLS. One-time activation codes must be generated and hashed server-side, expire, be single-use, and be redeemed transactionally. Admin authorization must be checked server-side, not by hiding buttons in the UI.

The current `www/app.js` is still a localStorage demo. This scaffold intentionally does not claim live sync or secure authentication until the backend is implemented and tested.
