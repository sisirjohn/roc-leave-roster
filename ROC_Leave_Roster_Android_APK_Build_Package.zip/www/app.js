(() => {
const FUNCTION_URL = "https://btxofpefxgnqrcsknilf.supabase.co/functions/v1/roc-board-access";
const $ = id => document.getElementById(id);
const TEAM_NAMES = ["NA STP", "EU STP", "Scheduling"];
let apiKey = "", token = "", role = "", people = [], leaves = [];
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; };
const escapeHtml = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),3000);}
function setError(msg){$("loginError").textContent=msg||"";}
async function call(action, data={}, needsAuth=true){
  const headers={"Content-Type":"application/json","apikey":apiKey};
  if(needsAuth && token) headers.Authorization=`Bearer ${token}`;
  const res=await fetch(FUNCTION_URL,{method:"POST",headers,body:JSON.stringify({action,...data})});
  let body={}; try{body=await res.json()}catch{}
  if(!res.ok) throw new Error(body.error || `Request failed (${res.status})`);
  return body;
}
function showApp(){
 $("loginScreen").hidden=true; $("app").hidden=false;
 $("roleLabel").textContent=role==="coordinator"?"Coordinator access":"Viewer access";
 document.querySelectorAll(".coordinator-only").forEach(el=>el.hidden=role!=="coordinator");
 $("connectionState").textContent="Cloud connected";
 $("todayLabel").textContent=new Date().toLocaleDateString("en-IN",{weekday:"short",day:"numeric",month:"short",year:"numeric"});
}
async function unlock(){
 apiKey=$("apiKey").value.trim(); const code=$("accessCode").value;
 if(!apiKey || !code){setError("Enter the Supabase publishable/anon key and your shared access code.");return;}
 $("loginBtn").disabled=true; $("loginBtn").textContent="Connecting…"; setError("");
 try{
  const result=await call("unlock",{code},false);
  token=result.access_token; role=result.role;
  if(!["viewer","coordinator"].includes(role)) throw new Error("Unexpected access role.");
  sessionStorage.setItem("roc_public_key",apiKey);
  showApp(); await refreshBoard();
 }catch(e){token="";role="";$("app").hidden=true;$("loginScreen").hidden=false;setError(e.message);}
 finally{$("loginBtn").disabled=false;$("loginBtn").textContent="Connect to roster";}
}
function mapPeople(rows){return (rows||[]).filter(p=>p.active).map(p=>({...p,name:p.full_name,team:p.team_name,role:"Associate",manager:"—"}));}
function mapLeaves(rows){return (rows||[]).map(l=>({id:l.id,employeeId:l.person_id,type:l.leave_type==="OPTIONAL_OFF"?"Optional Off":l.leave_type==="OTHER"?"Other":l.leave_type,duration:l.portion==="full"?1:.5,start:l.leave_date,end:l.leave_date,reason:l.notes||"",status:l.status[0].toUpperCase()+l.status.slice(1),portion:l.portion,createdAt:Date.now()}));}
async function refreshBoard(){
 $("connectionState").textContent="Refreshing…";
 try{
  const data=await call("get-board");
  people=mapPeople(data.people); leaves=mapLeaves(data.leave);
  render(); $("connectionState").textContent="Cloud synced";
 }catch(e){$("connectionState").textContent="Sync error";toast(e.message);}
}
function leaveForPersonDate(personId,date){return leaves.filter(l=>l.employeeId===personId&&l.start===date&&l.status==="Approved");}
function status(p){const ls=leaveForPersonDate(p.id,today());const sum=ls.reduce((n,l)=>n+l.duration,0);return sum>=1?"On leave":sum>0?"Half day":"Available";}
function render(){
 const q=$("search").value.trim().toLowerCase(),team=$("teamFilter").value;
 const filtered=people.filter(p=>(team==="All teams"||p.team===team)&&p.name.toLowerCase().includes(q));
 $("headcount").textContent=people.length;
 let leaveUnits=0;people.forEach(p=>leaveUnits+=Math.min(1,leaveForPersonDate(p.id,today()).reduce((n,l)=>n+l.duration,0)));
 $("onLeave").textContent=leaveUnits.toFixed(leaveUnits%1?1:0);
 $("available").textContent=Math.max(0,people.length-leaveUnits).toFixed(people.length-leaveUnits%1?0:0);
 $("shrinkage").textContent=(people.length?leaveUnits/people.length*100:0).toFixed(1)+"%";
 $("peopleRows").innerHTML=filtered.map(p=>`<tr><td><b>${escapeHtml(p.name)}</b></td><td>${escapeHtml(p.team)}</td><td><span class="status ${status(p)==="Available"?"ok":status(p)==="Half day"?"half":"away"}">${status(p)}</span></td><td>${role==="coordinator"?`<button class="small-btn" data-deactivate="${p.id}">Deactivate</button>`:"View only"}</td></tr>`).join("")||'<tr><td colspan="4" class="empty">No employees found.</td></tr>';
 const activeIds=new Set(people.map(p=>p.id));
 const rows=leaves.filter(l=>activeIds.has(l.employeeId)).sort((a,b)=>a.start.localeCompare(b.start));
 $("leaveRows").innerHTML=rows.map(l=>{const p=people.find(x=>x.id===l.employeeId);return `<tr><td>${escapeHtml(p?.name||"Unknown")}</td><td>${escapeHtml(l.start)}</td><td>${escapeHtml(l.type)}</td><td>${l.portion==="full"?"Full day":l.portion==="first_half"?"First half":"Second half"}</td><td><span class="status ${l.status==="Approved"?"ok":l.status==="Pending"?"half":"away"}">${escapeHtml(l.status)}</span></td><td>${role==="coordinator"?`<button class="small-btn" data-delete-leave="${l.id}">Remove</button>`:"View only"}</td></tr>`}).join("")||'<tr><td colspan="6" class="empty">No leave records.</td></tr>';
 $("leavePerson").innerHTML=people.map(p=>`<option value="${p.id}">${escapeHtml(p.name)} · ${escapeHtml(p.team)}</option>`).join("");
}
function openModal(id){if(role!=="coordinator")return;$(id).hidden=false;if(id==="leaveModal")$("leaveDate").value=today();}
function closeModal(id){$(id).hidden=true;}
async function addPerson(e){
 e.preventDefault();const name=$("personName").value.trim(),team=$("personTeam").value;
 try{await call("add-person",{full_name:name,team_name:team});closeModal("personModal");$("personForm").reset();await refreshBoard();toast("Employee added to shared roster.");}
 catch(err){toast(err.message);}
}
async function addLeave(e){
 e.preventDefault();
 const payload={person_id:$("leavePerson").value,leave_date:$("leaveDate").value,leave_type:$("leaveType").value,portion:$("leavePortion").value,status:$("leaveStatus").value,notes:$("leaveNotes").value.trim()};
 try{await call("set-leave",payload);closeModal("leaveModal");$("leaveForm").reset();await refreshBoard();toast("Leave saved to shared roster.");}
 catch(err){toast(err.message);}
}
async function deactivate(id){
 if(!confirm("Deactivate this employee from the active roster? Existing leave records are retained."))return;
 try{await call("update-person",{id,active:false});await refreshBoard();toast("Employee deactivated.");}
 catch(e){toast(e.message);}
}
async function deleteLeave(id){
 if(!confirm("Remove this leave record?"))return;
 try{await call("delete-leave",{id});await refreshBoard();toast("Leave removed.");}
 catch(e){toast(e.message);}
}
function logout(){token="";role="";people=[];leaves=[];$("app").hidden=true;$("loginScreen").hidden=false;$("accessCode").value="";setError("");$("connectionState").textContent="Locked";}
function bind(){
 $("loginBtn").addEventListener("click",unlock);
 $("accessCode").addEventListener("keydown",e=>{if(e.key==="Enter")unlock();});
 $("refreshBtn").addEventListener("click",refreshBoard);
 $("logoutBtn").addEventListener("click",logout);
 $("addPersonBtn").addEventListener("click",()=>openModal("personModal"));
 $("addLeaveBtn").addEventListener("click",()=>openModal("leaveModal"));
 $("personForm").addEventListener("submit",addPerson);
 $("leaveForm").addEventListener("submit",addLeave);
 document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>closeModal(b.dataset.close)));
 $("search").addEventListener("input",render);$("teamFilter").addEventListener("change",render);
 $("peopleRows").addEventListener("click",e=>{const b=e.target.closest("[data-deactivate]");if(b)deactivate(b.dataset.deactivate);});
 $("leaveRows").addEventListener("click",e=>{const b=e.target.closest("[data-delete-leave]");if(b)deleteLeave(b.dataset.deleteLeave);});
}
const savedKey=sessionStorage.getItem("roc_public_key");if(savedKey)$("apiKey").value=savedKey;
bind();
})();