# ROC Leave & Roster — cross-platform build scaffold

This project reuses one web UI for:
- Android APK via Capacitor
- iOS app via Capacitor
- Windows installer via Electron
- Browser/PWA

## Current status
This ZIP is the source project and build scaffold, not compiled APK/EXE/IPA binaries. The execution environment used to prepare it has Node and Java but no Android SDK/Gradle or Xcode. Android and iOS packages must be compiled with the appropriate toolchains.

The included app is still a local demo. Leave requests, roles and roster are stored in browser/local app storage only. The cloud backend is not connected, so devices do not sync. Demo role switching is not secure authentication. Do not use real employee data.

## Android APK build (Windows/macOS/Linux)
1. Install Node.js LTS and Android Studio.
2. Install Android SDK Platform Tools and a current Android SDK platform in Android Studio.
3. Extract this project.
4. In a terminal opened in this folder run:
   ```sh
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
5. In Android Studio choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK is usually at `android/app/build/outputs/apk/debug/app-debug.apk`.
   For sharing beyond testing, create a signed release APK from Android Studio.

## iOS build
Requires macOS and Xcode:
```sh
npm install
npx cap add ios
npx cap sync ios
npx cap open ios
```
Select a signing team in Xcode and build. App Store distribution requires Apple developer account and provisioning.

## Windows installer
Build on Windows for the most reliable result:
```powershell
npm install
npm run build:win
```
The installer should be created under `dist/`. Windows may flag an unsigned installer; signing is a separate optional setup.

## Free-tier hosting for the PWA
Deploy the contents of `www/` to an HTTPS static host. Keep all files together. Install from the HTTPS link on Android/iPhone.

## Production readiness checklist
- Obtain company approval for handling employee data and hosting.
- Connect a shared Supabase project.
- Implement Supabase Auth, server-side single-use activation, database schema and RLS policies.
- Add Realtime, audit trail, backups, monitoring and recovery.
- Test approvals, concurrent edits, time zones, leave overlaps and role permissions.
