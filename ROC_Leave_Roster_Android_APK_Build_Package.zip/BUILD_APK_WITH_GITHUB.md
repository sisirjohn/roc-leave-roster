# Build your APK using GitHub Actions (no computer build tools needed locally)

1. Sign in to GitHub and create a new repository. Keep it private if you prefer.
2. Upload the extracted contents of this ZIP into the repository. Make sure `.github/workflows/build-android-apk.yml` is included. Some upload interfaces hide `.github`; use GitHub's web editor to create that workflow file if it did not upload.
3. Open the repository's **Actions** tab.
4. Select **Build ROC Leave & Roster APK** on the left.
5. Tap **Run workflow** and confirm.
6. Wait for the run to finish successfully.
7. Open the completed run and download the **ROC-Leave-Roster-debug-APK** artifact. GitHub downloads artifacts as a ZIP; extract it to get `app-debug.apk`.
8. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

A GitHub account is required. GitHub Actions usage quotas/availability may apply.

Important: this builds the current demo prototype only. It does not add cloud sync or secure authentication. Do not use real employee data.
